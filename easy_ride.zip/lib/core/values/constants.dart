class Constants {
  // API Keys
  static const String supabaseUrl = 'https://adssiilqfzicseiwemwf.supabase.co';
  static const String supabaseKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImFkc3NpaWxxZnppY3NlaXdlbXdmIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDQ2MTkzMzYsImV4cCI6MjA2MDE5NTMzNn0.55zK16pIYiQf8i2K2Lx5ogbMvPrGqUaKi9rztJFO_Gg';
  static const String fcmServerKey = 'YOUR_FCM_SERVER_KEY';
  static const String googleMapsApiKey = 'AIzaSyChl4laJOHV3davKdctReIRj5JWDcTClvg';
  // App-wide constants
  static const String appName = 'Easy Ride';
  static const String appVersion = '1.0.0';

  // Firebase collections
  // Firebase collections
  static const String usersCollection = 'users';
  static const String ridesCollection = 'rides';
  static const String driversCollection = 'drivers';
  static const String chatsCollection = 'chats';
  static const String messagesCollection = 'messages';
  static const String reportsCollection = 'reports';
  static const String notificationsCollection = 'notifications';
  static const String driverLocationsCollection = 'driverLocations';
  static const String savedLocationsCollection = 'savedLocations';


  // Supabase storage paths
  static const String profileImagesPath = 'profileImages';
  static const String documentImagesPath = 'documentImages';

  // Ride types
  static const String standardRide = 'Standard';
  static const String premiumRide = 'Premium';
  static const String xlRide = 'XL';

  // Payment methods
  static const String cardPayment = 'card';
  static const String cashPayment = 'cash';
  static const String walletPayment = 'wallet';

  // Ride statuses
  static const String pending = 'pending';
  static const String accepted = 'accepted';
  static const String arrived = 'arrived';
  static const String started = 'started';
  static const String completed = 'completed';
  static const String cancelled = 'cancelled';

  // Location types
  static const String home = 'home';
  static const String work = 'work';
  static const String favorite = 'favorite';
  static const String recent = 'recent';

  // Verification statuses
  static const String pending_verification = 'pending';
  static const String approved = 'approved';
  static const String rejected = 'rejected';

  // Default values
  static const double defaultMapZoom = 15.0;
  static const double baseFare = 2.5;
  static const double perKmRate = 1.2;
  static const double perMinuteRate = 0.25;
  static const double cancellationFee = 5.0;

  // Timeouts
  static const int rideRequestTimeoutSeconds = 60;
  static const int otpVerificationTimeoutSeconds = 60;

  // UI constants
  static const double borderRadius = 16.0;
  static const double buttonHeight = 50.0;
  static const double inputHeight = 56.0;
  static const double cardElevation = 4.0;
}
